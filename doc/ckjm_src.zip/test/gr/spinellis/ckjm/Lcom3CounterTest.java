/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gr.spinellis.ckjm;

//import gr.spinellis.ckjm.ClassVisitor.Lcom3Counter;
import java.util.TreeSet;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author marian
 */
public class Lcom3CounterTest {

    @Before
    public void setUp() {
    }

    /**
     * Test of isJdkIncluded method, of class CountingProperities.
     */
    @Test
    public void testLcom3() {
        TreeSet<String> ts=null;
        String method=null;
        //Lcom3Counter lcom = new Lcom3Counter(ts,method);
        //TODO: Lcom3Counter should be removed from ClassVisitor and the it should be tested.
    }
}
