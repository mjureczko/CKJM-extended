/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gr.spinellis.ckjm;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author marian
 */
public class MetricsFilterTest {

    public MetricsFilterTest() {
    }


    @Before
    public void setUp() {
    }



    /**
     * Test of main method, of class MetricsFilter.
     */
    @Test
    public void testMain() throws FileNotFoundException, IOException {

        String[] mExpected =
        {
            "KlasaTestowaParent 2 1 0 1 5 0 0 1 2 0,0000 21 1,0000 0 0,0000 0,7500 0 0 9,0000",
            " ~ public int sru(): 1",
            " ~ public void <init>(int id): 1",
            "KlasaTestowa2 5 1 0 1 11 4 1 1 0 0,4167 53 0,3333 1 0,0000 0,6250 0 0 9,0000",
            " ~ void <init>(): 1",
            " ~ static void <clinit>(): 1",
            " ~ int m3(int jk): 1",
            " ~ void m2(): 1",
            " ~ void m1(): 2",
            "KlasaTestowa 3 1 0 2 8 1 2 1 1 0,0000 115 0,0000 0 0,0000 0,5556 0 0 37,0000",
            " ~ public void <init>(): 1",
            " ~ void m2(String name, java.util.List list, String c): 6",
            " ~ void m1(): 7"
        };
        String out = "system_out.txt";
        
        System.setOut(new PrintStream(new FileOutputStream(out)));
        String argv[] = {"./build/test/classes/KlasaTestowa.class", 
                         "./build/test/classes/KlasaTestowa2.class",
                         "./build/test/classes/KlasaTestowaParent.class"};
        MetricsFilter.main(argv);

        String[] outContent = readFile(out);

        Arrays.sort(mExpected);
        Arrays.sort(outContent);

        for( int i=0; i<outContent.length; i++ ){
            assertEquals( "testing: "+outContent[i], mExpected[i], outContent[i] );

        }
        //TODO: The standard output should be restored.
    }

    public static String[] readFile(String file) throws FileNotFoundException, IOException {
        BufferedReader reader = new BufferedReader(new FileReader(file));
        String line = null;
        List<String> result = new ArrayList<String>();
        String[] tmp = new String[1];
        while ((line = reader.readLine()) != null) {
            if( !line.matches("\\s*") )
                result.add(line);
        }
        return result.toArray( tmp );
    }

}